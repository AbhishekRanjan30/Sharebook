﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string output = "";
        try
        {
            string username=Request.QueryString["uname"];
            string userid = Request.QueryString["uid"];
            string password = Request.QueryString["pass"];
            string email = Request.QueryString["email"];
            string mobile = Request.QueryString["mob"];
            string address = Request.QueryString["add"];
            string city = Request.QueryString["city"];
            string pincode = Request.QueryString["pin"];
            string shop = Request.QueryString["shop"];
            string usertype = Request.QueryString["utype"];

            DataSet1TableAdapters.usersTableAdapter uta = new DataSet1TableAdapters.usersTableAdapter();
            DataSet1.usersDataTable udt = uta.GetDataByUserid(userid);
            if (udt.Rows.Count > 0)
                throw new Exception("Sorry !!! This UserID is already Registered.");
            uta.Insert(username, userid, password, email, mobile, address, city, pincode, shop, usertype, "Active");

            if (shop.Equals("Yes"))
            {
                int uno = (int)uta.GetLastSno();

                string shopname = Request.QueryString["shopname"];
                string shopaddress = Request.QueryString["shopadd"];
                string GSTIN = Request.QueryString["gst"];

                DataSet1TableAdapters.shopTableAdapter sta = new DataSet1TableAdapters.shopTableAdapter();
                sta.Insert(uno, shopname, shopaddress, GSTIN, "Active");
            }

            output = "{\"msg\":\"success\"}";
        }
        catch (Exception ex)
        {
            output = "{\"msg\":\"error\",\"err\":\""+ex.Message+"\"}";
        }
        finally
        {
            Response.Write(""+output);
        }
    }
}