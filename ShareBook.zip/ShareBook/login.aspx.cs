﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string output = "";
        try
        {
            string userid = Request.QueryString["uid"];
            string password = Request.QueryString["pass"];

            DataSet1TableAdapters.usersTableAdapter uta = new DataSet1TableAdapters.usersTableAdapter();
            DataSet1.usersDataTable udt = uta.GetDataByUserid(userid);
            if (udt.Rows.Count <= 0)
                throw new Exception("No Such User Found");
            else
            {
                DataSet1.usersRow ur = (DataSet1.usersRow)udt.Rows[0];
                if(!userid.Equals(""+ur.userid))
                    throw new Exception("No Such User Found");
                if(!password.Equals(""+ur.password))
                    throw new Exception("Invalid Password. Try Again");
                output = "{\"msg\":\"success\",\"uno\":\""+ur.sno+"\",\"uname\":\""+ur.username+"\",\"utype\":\""+ur.usertype+"\"}";
            }

        }
        catch (Exception ex)
        {
            output = "{\"msg\":\"error\",\"err\":\"" + ex.Message + "\"}";
        }
        finally
        {
            Response.Write("" + output);
        }
    }
}