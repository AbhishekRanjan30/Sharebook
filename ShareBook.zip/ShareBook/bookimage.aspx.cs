﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class bookimage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Request.QueryString.HasKeys())
        {
            lblMsg.Text = "";
            Label1.Text = "Invalid Request";
        }
    }
    protected void btnGo_Click(object sender, EventArgs e)
    {
        try
        {
            if (!Request.QueryString.HasKeys())
                throw new Exception("Invalid Request");
            int bno = Convert.ToInt32(Request.QueryString["bno"]);
            if (bkImg.HasFile)
            {
                string folder = Server.MapPath("books\\" + bno);
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);
                bkImg.SaveAs(folder + "\\" + bkImg.FileName);
                DataSet1TableAdapters.bookdetailsTableAdapter bdta = new DataSet1TableAdapters.bookdetailsTableAdapter();
                bdta.UpdateBookImage("books/" + bno + "/" + bkImg.FileName, bno);
                Label1.Text = "";
                lblMsg.Text = "Image Uploaded Successfully";
            }
            else
                throw new Exception("Please Select A Book Image To Upload");
        }
        catch (Exception ex)
        {
            lblMsg.Text = "";
            Label1.Text = ex.Message;
        }
    }
}