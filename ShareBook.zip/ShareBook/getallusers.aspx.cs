﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class getallusers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string output = "";

        try
        {
            DataSet1TableAdapters.usersTableAdapter uta = new DataSet1TableAdapters.usersTableAdapter();
            DataSet1.usersDataTable udt = uta.GetData();

            if (udt.Rows.Count <= 0)
            {
                output += "{\"msg\":\"success\",\"userscount\":\"0\"}";
            }
            else
            {
                output += "{\"msg\":\"success\",\"userscount\":\""+udt.Rows.Count+"\",\"userslist\":[";
                for (int i = 0; i < udt.Rows.Count; i++)
                {
                    DataSet1.usersRow ur = (DataSet1.usersRow)udt.Rows[i];
                    output += "{\"uno\":\""+ur.sno+"\",\"username\":\""+ur.username+"\",\"userid\":\""+ur.userid+"\",\"email\":\""+ur.email+"\",\"mobile\":\""+ur.mobile+"\",\"address\":\""+ur.address+"\",\"city\":\""+ur.city+"\",\"pincode\":\""+ur.pincode+"\",\"shop\":\""+ur.shop+"\"";

                    if (ur.shop.Equals("Yes"))
                    {
                        DataSet1TableAdapters.shopTableAdapter sta = new DataSet1TableAdapters.shopTableAdapter();
                        DataSet1.shopDataTable sdt = sta.GetDataByuno(ur.sno);
                        DataSet1.shopRow sr = (DataSet1.shopRow)sdt.Rows[0];

                        output += ",\"shopname\":\""+sr.shopname+"\",\"shopaddress\":\""+sr.shopaddress+"\",\"gstin\":\""+sr.GSTIN+"\"";
                    }
                    output += "}";
                    if (i < udt.Rows.Count - 1)
                        output += ",";
                }
                output += "]}";
            }
        }

        catch (Exception ex)
        {
            output = "{\"msg\":\"error\",\"err\":\"" + ex.Message + "\"}";
        }

        finally { Response.Write(output); }
    }
}