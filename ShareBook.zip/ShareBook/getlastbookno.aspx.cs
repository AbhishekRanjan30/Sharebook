﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class getlastbookno : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        string output = "";

        try
        {

            DataSet1TableAdapters.bookdetailsTableAdapter bdta = new DataSet1TableAdapters.bookdetailsTableAdapter();
            int bsno = (int)bdta.GetLastBookSno();

            output = "{\"msg\":\"success\",\"bno\":\"" + bsno + "\"}";

        }
        catch (Exception ex)
        {

            output = "{\"msg\":\"error\",\"err\":\"" + ex.Message + "\"}";
        }
        finally {

            Response.Write(output);
        }


    }
}