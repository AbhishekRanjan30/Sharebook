﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class uploadnewbook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string output = "";

        try
        {
            string bookname = Request.QueryString["bname"];
            string isbn = Request.QueryString["isbn"];
            string subject = Request.QueryString["subject"];
            string stream = Request.QueryString["stream"];
            string author = Request.QueryString["author"];
            string publisher = Request.QueryString["publisher"];
            double price = Convert.ToDouble(Request.QueryString["price"]);
            double saleprice=Convert.ToDouble(Request.QueryString["saleprice"]);
            string description = Request.QueryString["description"];
            string condition = Request.QueryString["condition"];
            string img = Request.QueryString["imgsrc"];
            int bookcopy=Convert.ToInt32(Request.QueryString["bookscopy"]);
            string tags = Request.QueryString["tags"];
            int ub = Convert.ToInt32(Request.QueryString["uno"]);
            DataSet1TableAdapters.bookdetailsTableAdapter bta = new DataSet1TableAdapters.bookdetailsTableAdapter();
            bta.Insert(bookname, isbn, subject, stream, author, publisher, price, saleprice, description, condition, img, bookcopy, tags, "Active", ub);
            int sno = (int)bta.GetLastBookSno();
            output = "{\"msg\":\"success\",\"sno\":\""+sno+"\"}";
        }
        catch (Exception ex)
        {
            output = "{\"msg\":\"error\",\"err\":\"Server\n" +ex+"\n" + ex.Message + "\"}";
        }
        finally
        {
            Response.Write("" + output);
        }
    }
}