﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class getbooks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        String output = "";

        try
        {
            DataSet1TableAdapters.bookdetailsTableAdapter bta = new DataSet1TableAdapters.bookdetailsTableAdapter();
            DataSet1.bookdetailsDataTable bdt = bta.GetData();

            if (bdt.Rows.Count <= 0)
            {
                throw new Exception("No Books Available !");
            }

            else
            {
                string booksList = "";
                for (int i = 0; i < bdt.Rows.Count; i++)
                {
                    DataSet1.bookdetailsRow br = (DataSet1.bookdetailsRow)bdt.Rows[i];

                    booksList += "{\"sno\":\""+br.sno+"\",\"bookname\":\"" + br.bname + "\",\"isbn\":\"" + br.isbn + "\",\"subject\":\"" + br.subject + "\",\"stream\":\"" + br.stream + "\",\"author\":\"" + br.author + "\",\"publisher\":\"" + br.publisher + "\",\"price\":\"" + br.price + "\",\"saleprice\":\"" + br.saleprice + "\",\"description\":\"" + br.description + "\",\"condition\":\"" + br.condition + "\",\"imgsrc\":\"" + br.imgsrc + "\",\"bookscopy\":\"" + br.bookscopy + "\",\"tags\":\"" + br.tags + "\",\"status\":\"" + br.status + "\",\"uploadby\":\""+br.uploadby+"\"}";
		    if(i<bdt.Rows.Count-1)
			booksList+=",";
                }
                output += "{\"msg\":\"success\",\"bookcount\":\"" + bdt.Rows.Count + "\",\"bookslist\":["+booksList+"]}";
            }
        }

        catch (Exception ex)
        {
            output = "{\"msg\":\"error\",\"err\":\"" + ex.Message + "\"}";
        }

        finally {

            Response.Write(output);
        }

    }
}